import time
import random
items = []


random_item = None


# Creating repetation of random items in the same game
def enemies():
    float_list = [
        'troll', 'gorgon', 'pirate', 'witch', 'wizard',
        'filthy goblin']
    global random_item
    if not random_item:  # if the random_item is not yet set
        random_item = random.choice(float_list)
    return random_item


# Providing print and sleep with one function
def print_pause(message_to_print):
    print(message_to_print)
    time.sleep(1)


# Providing print and sleep with one function but having three arguments
def print_pause2(argu1, argu2, argu3):
    print(argu1, argu2, argu3)
    time.sleep(1)


# Making sure that any invalid input will be replied properly
def valid_input(prompt, option1, option2):
    while True:
        response = input(prompt).lower()
        if option1 in response:
            break
        elif option2 in response:
            break
        else:
            print_pause("Sorry, Please try again.")
    return response


# This function shows what happens in the cave
def cave():
    if "Sword of Zenda" in items:
        print_pause(
            "You've been here before, and gotten all the good stuff."
            "It's just an empty cave now.")
    else:
        print_pause(
            "It turns out to be only a very small cave.\n"
            "Your eye catches a glint of metal behind a rock.")
        print_pause(
            "You have found the magical Sword of Zenda!\n"
            "You discard your silly old knife and take the sword with you.")
    items.append("Sword of Zenda")


# This function shows what happens in the house
def house():
    print_pause("You approach the door of the house.")
    print_pause2(
        "You are about to knock when the door "
        "opens and out steps a", enemies(), "which is frightening!")
    print("Eep! This is the", enemies() + "'s", "house!")
    time.sleep(1)
    print_pause2("The", enemies(), "attacks you!\n")


# Whatever happens you come back here if you run or return from cave
def field():
    print_pause("You walk back out to the field.")
    game_choice()


# Decides whether player wants to fight the enemy or run away
def fight_or_run():
    print_pause(
        "You feel a bit under-prepared for this, "
        "because of only having a tiny knife.")
    response1 = valid_input("Would you like to (1) fight or (2) run away?\n",
                            "1", "2")
    if response1 == "1":
        if 'Sword of Zenda' in items:
            print_pause2(
                "As the", enemies(), "moves to attack, "
                "you unsheath your new sword.")
            print_pause2(
                "The Sword of Zenda shines brightly in your hand "
                "as you brace yourself for the attack.\n"
                "But the", enemies(), "takes one look at "
                "your shiny new toy and runs away!\n"
                "You have rid the town of the enemy. "
                "You are victorious!")
        else:
            print_pause("You did your best...")
            print_pause2(
                "But your dagger is no match for the",
                enemies(), "and it's crafts.")
            print_pause("You have been defeated!")
        return
    elif response1 == "2":
        print_pause(
            "You run back into the field. Luckily,"
            "you don't seem to have been followed.")
    else:
        print_pause(
            "I do not understand your input.\n"
            "Please try again!")
        fight_or_run()


# Introduction of the game
def intro():
    print_pause(
        "You find yourself standing in an open field, "
        "filled with grass, lavendar and yellow wildflowers.")
    print_pause2(
        "Rumor has it that a", enemies(), "is somewhere around here, "
        "and has been terrifying the nearby village....")
    print_pause("In front of you is a house.")
    print_pause("To your right is a dark cave.")
    print_pause(
        "In your hand you hold your trusty "
        "(but not very effective) knife.\n")


# Choice of the gameplay
def game_choice():
    response = valid_input(
        "Enter 1 to knock on the door of the house.\n"
        "Enter 2 to peer into the cave.\n"
        "What would you like to do?\n"
        "(Please enter 1 or 2)\n",
        "1", "2")
    if response == "1":
        house()
        fight_or_run()
    elif response == "2":
        print_pause("You peer cautiously into the cave.\n")
        cave()
        field()
    else:
        print_pause(
            "I do not understand your input.\n"
            "Please try again!")
        game_choice()


# Decides if the player wants to play again
def play_again():
    response2 = valid_input("Would you like to play again? (yes/no)\n",
                            "yes", "no")
    if response2 == "yes":
        print_pause("Excellent! Restarting the game ...")
        play_game()
    elif response2 == "no":
        print_pause("Thank you for playing this game!")
    else:
        print(
            "I don't understand your input.\n"
            "Please try again!")
        play_again()
    return


# Main gameplay
def play_game():
    intro()
    game_choice()
    play_again()


play_game()
